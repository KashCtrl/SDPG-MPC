function MPC_run

close all
coder.extrinsic('tic','toc','addpath','quadprog','assignin','osqpsolver')
addpath("./solver/")

%% ===================== SETTINGS =========================================

% ----------------------------------------------------- SIMULATION SETTINGS
% * Simulation time length [s]
te  = 2;
% * Sampling period [s]
dt  = 0.1/1000;
% * Time measurement mode
%   If true: skip logging & visualization
%            introduce pseudo-random periodic initialization
t_mode = false;

% ---------------------------------------------------------- PLANT SETTINGS
% * Plant matrix (Continuous-time LTI)
Ac  = [-4 -0.03; 0.75 -10];
Bc  = [2;0];

% * Initial state
x0  = [0;0];

% -------------------------------------------------------- PROBLEM SETTINGS
% * Reference
xr  = [200/3;5];
ur  = -Bc\Ac * xr;

% * Input bounds
ulb = [];
uub = [160];

% * Weights
% - Cost matrix for state x
Qk  = 2e+0*diag([1,1]);
% - Cost matrix for input u
Rk  = 2e-1*diag([1]);

% * Prediction horizon
% - Time length [s]
Th  = 3.0;
% - Division
Nh  = 30;

% --------------------------------------------------------- SOLVER SETTINGS
% * Solver
%   0: iMPC with stability evaluation (require YALMIP)
%   1: iMPC (easy code)
%   2: iMPC (fast code for codegen),
%   3: QP (FBRS)
%   4: QP (QPKWIK)
%   5: QP (OSQP, require OSQP package),
%   6: QP (OSQPmex, require preparation of OSQP MEX named "osqpsolver")
%   7: QP (quadprog, require Optimization Toolbox)
%   8: Explicit MPC (pre-designed. cannot change problem.)
%   9: C/GMRES
solver = 0;

% * iMPC parameter (for solver 0-2)
zeta  = 1000;
alpha = 0.2;
beta  = 0.1;
c_bs  = 0.5;    % Coefficient in Algorithm 1
proj  = true;   % Equality constraint projection (Section 4.4)
dlt_d = 0.4578; % Paste from result of solver 0

%% ========================= MPC PREPROCESS ===============================

% * Dimension
Nt  = numel(0:dt:te);   % time
Nx  = size(Bc,1);       % state
Nu  = size(Bc,2);       % input
NX  = Nh*Nx;            % state sequence
NU  = Nh*Nu;            % input sequence
Nw  = Nh*Nu + Nh*Nx;    % primal
Ix  = eye(Nx);
Iu  = eye(Nu);
Iw  = eye(Nw);

% * Discrete-time plant (Holder + LTI + Sampler)
Ad = expm(dt*Ac);
Bd = (Ad-Ix)/Ac*Bc;

% * Control model
dtau = Th./Nh; % prediction time-step
Ah = expm(dtau*Ac);
Bh = (Ah-Ix)/Ac*Bc;

% * Objective function : f(w) = 1/2 w'*P*w, dfdw(0) = 0
Qf = repmat2d(Qk,[Nh,Nh],1:Nh,1:Nh);
Rf = repmat2d(Rk,[Nh,Nh],1:Nh,1:Nh);
P  = blkdiag(Rf,Qf); Pvec = diag(P);

% * Inequality constraint : g(w;x) <= 0, g(0;0) < 0 or g(0;0) <= 0
if ~isempty(uub) 
    bgub = repmat(uub-ur,Nh,1);
    Agub = [eye(NU),zeros(NU,NX)];
    useuub = true;
else
    bgub = []; Agub = []; useuub = false;
end
if ~isempty(ulb)
    bglb = repmat(ur-ulb,Nh,1);
    Aglb = [-eye(NU),zeros(NU,NX)];
    useulb = true;
else
    bglb = []; Aglb = []; useulb = false;
end
Ag  = [Agub;Aglb]; bg = [bgub;bglb]; 
Nmu = size(bg,1);

% * Equality constraint : h(w;x) = Cw + Dx, h(0;0) = 0
Cx  = (repmat2d(Ah,[Nh,Nh],2:Nh,1:Nh-1) - eye(NX));
Cu  =  repmat2d(Bh,[Nh,Nh],1:Nh,1:Nh);
C   = [Cu,Cx]; D = [Ah;zeros((Nh-1)*Nx,Nx)];
Nlm = size(C,1);
Ilm = eye(Nlm);

% * Log array
LOG      = struct;
LOG.T    = dt*(0:Nt-1); % Time
LOG.U    = NaN( Nu,Nt); % Input
LOG.X    = NaN( Nx,Nt); % State
LOG.UR   = NaN( Nu,Nt); % Input reference
LOG.XR   = NaN( Nx,Nt); % State reference
LOG.UUB  = NaN( Nu,Nt); % Input upper bound
LOG.Ns   = NaN(  1,Nt); % Iterations

% * Solver-specific process
if solver <= 2 % ----------------------------------------------------- iMPC

    % * Constants
    kappa = 1 + 2*alpha*beta;
    tau   = 1 / (1+alpha*beta);
    dtzeta= dt*zeta;
    E = [Iu,zeros(Nu,Nw-Nu)];
    if proj % with projection
        CCTi = inv(C*C');
        K = Iw - C'*CCTi*C;
        L = - C'*CCTi*D;
    else % without projection
        K = eye(Nw);
        L = zeros(Nw,Nx);
    end
    AgKT = (Ag*K)';

    % * Initialization
    w0  = K*zeros(Nw,1) + L*(x0-xr);
    mu0 = zeros(Nmu,1); lm0 = zeros(Nlm,1); V0 = inf;

    % * Stability evaluation and delta setting
    if solver == 0
        iMPC_stability_evaluation;
    end

else % ------------------------------------------------------------- Others

    % * Convestion matrix for eliminating equality constraint
    % - w = Wu * U + Wx * xt
    Wu = [eye(NU); -Cx\Cu];
    Wx = [zeros(NU,Nx); -Cx\D];
    % - f(U) = 1/2*U'*Hu*U + fu'*U + const.
    Hu    = Wu'*P*Wu;
    WuPWx = Wu'*P*Wx; % fu = WuPWx * xt;
    % - g(U) = AgWu U + ( AgWx * xt - bg ) <= 0
    AgWu = Ag*Wu;
    AgWx = Ag*Wx;

    % * Initialization
    U0  = zeros(NU,1);
    LM0 = zeros(Nmu,1);
    u0  = zeros(Nu,1);
    if solver == 5 % OSQP
        m = osqp; settings = m.default_settings();
        settings.verbose = false; 
        settings.eps_abs = 1e-2;
        settings.eps_rel = 1e-2;
        settings.warm_start = true;
        settings.check_termination = 1; 
        fu = WuPWx*(x0-xr); bgu = bg - AgWx*(x0-xr);
        m.setup(Hu,fu,AgWu,-inf*bgu,bgu,settings);
        % for codegen
        % m.codegen('osqpsolver','mexname', 'osqpsolver','force_rewrite',true);
        % return
    elseif solver == 6 % OSQP mex
        U = U0; % type fix
    elseif solver == 8 % Explicit MPC
        Data = load('EMPC_PAS.mat');
        PAS  = Data.PAS;
    elseif solver == 9 % C/GMRES
        gmres_iter = 1; % number of internal iteration
    end

end

%% ============================ MAIN LOOP ==================================
Niter = 0; rng(1);
tStart = tic;
for k = 1:Nt
    
    s = 1; % Step counter

    % * Controller
    switch solver
        case {0,1} % ------------------------------------  IMPC (easy code)

        % * Input decision
        x = x0; w = w0; mu = mu0; lm = lm0; V = V0;
        wproj = K*w + L*(x-xr); % if not proj: K = I, L = 0 => wproj = w
        u = E* wproj + ur;
        
        % * State update
        % - Functions and gradients
        g  = Ag*wproj - bg; h = C*w + D*(x-xr);
        df = P*w; dg = K'*Ag'; dh = C';
        % - Maximum step size (Definition 4.4)
        gp = max(0,g); gp(mu>0) = g(mu>0); % = [g(w)]_{mu}^+
        etamax = -mu./(dtzeta*gp); etamax(mu+dtzeta*gp>=0) = 1;
        % - Initial update (Controller C_d)
        eta = etamax; gamma = 1;
        lm0 = lm + dtzeta*tau*(h-alpha*lm);
        mu0 = mu + dtzeta*gp.*eta;
        w0  = w  - dtzeta*(df+dg*(mu.*eta)+kappa*dh*(lm+beta*(lm0-lm)/dtzeta));
        e0  = (Ad*x + Bd*u) - xr;
        V0  = (w0'*w0 + mu0'*mu0 + lm0'*lm0 + dlt_d*zeta*(e0'*e0))/2;
        % - Back-stepping search (Algorithm 1)
        while V0 >= V && V0 >= 1e-10
            s = s + 1; gamma = gamma/c_bs; 
            eta = etamax*gamma;
            mu0 = mu + dtzeta*gp.*eta;
            w0  = w  - dtzeta*(df+dg*(mu.*eta)+kappa*dh*(lm+beta*(lm0-lm)/dtzeta));
            V0  = (w0'*w0 + mu0'*mu0 + lm0'*lm0 + dlt_d*zeta*(e0'*e0))/2;
        end
        mu0 = max(0,mu0); % for safety
        
        case 2 % ----------------------------------------  IMPC (fast code)
        
        % * Input decision
        x = x0; w = w0; mu = mu0; lm = lm0; V = V0; xt = x-xr;
        if proj
            [wproj,h] = projection(w,xt,L*xt,Ah,Bh,CCTi,Nu,Nx,Nh);
        else
            wproj = w; 
            h = dynamics(w,xt,Ah,Bh,Nu,Nx,Nh);
        end
        u = wproj(1:Nu) + ur;
        
        % * State update
        % - Maximum step size (Definition 4.4)
        g  = Agtimes(wproj,useuub,useulb,Nu,Nx,Nh) - bg;
        gp = max(0,g); gp(mu>0) = g(mu>0); % = [g(w)]_{mu}^+
        etamax = -mu./(dtzeta*gp); etamax(mu+dtzeta*gp>=0) = 1;
        % - Initial update
        eta = etamax;
        lm0 = (1-dtzeta*tau*alpha)*lm + dtzeta*tau*h;
        mu0 = mu + dtzeta*gp.*eta;
        if proj
            w0 = w - dtzeta*(Pvec.*w+AgKT*(mu.*eta)+CTtimes(kappa*((1-beta/dtzeta)*lm+beta/dtzeta*lm0),Ah,Bh,Nu,Nx,Nh));
        else
            w0 = w - dtzeta*(Pvec.*w+AgTtimes(mu.*eta,useuub,useulb,Nu,Nx,Nh)+CTtimes(kappa*((1-beta/dtzeta)*lm+beta/dtzeta*lm0),Ah,Bh,Nu,Nx,Nh));
        end
        e0  = (Ad*x + Bd*u) - xr;
        V0  = (w0'*w0 + mu0'*mu0 + lm0'*lm0 + dlt_d*zeta*(e0'*e0))/2;
        % - Back-stepping search (Algorithm 1)
        while V0 >= V && V0 >= 1e-10
            s = s + 1; eta = eta*c_bs;
            mu0 = mu + dtzeta*gp.*eta;
            if proj
                w0 = w - dtzeta*(Pvec.*w+AgKT*(mu.*eta)+CTtimes(kappa*((1-beta/dtzeta)*lm+beta/dtzeta*lm0),Ah,Bh,Nu,Nx,Nh));
            else
                w0 = w - dtzeta*(Pvec.*w+AgTtimes(mu.*eta,useuub,useulb,Nu,Nx,Nh)+CTtimes(kappa*((1-beta/dtzeta)*lm+beta/dtzeta*lm0),Ah,Bh,Nu,Nx,Nh));
            end
            V0  = (w0'*w0 + mu0'*mu0 + lm0'*lm0 + dlt_d*zeta*(e0'*e0))/2;
        end
        mu0 = max(0,mu0); % for safety

        case {3,4,5,6,7} % -------------------------------------------- QPs

        % * Problem definition
        x = x0; xt = x-xr;
        fu  = WuPWx*xt;
        bgu = bg - AgWx*xt;

        % * Solve QP
        if solver == 3
            [U,LM,~,~,s] = FBRS(Hu,fu,AgWu,bgu,U0,LM0,1e-6,1e-3,100);
        elseif solver == 4
            [U,~,~,~,s] = QPKWIK(Hu,fu,AgWu,bgu);
        elseif solver == 5 
            m.update(q=fu, u=bgu);
            Result = m.solve();
            U = Result.x;
            s = Result.info.iter;
        elseif solver == 6
            osqpsolver('update_lin_cost', fu);
            osqpsolver('update_upper_bound',bgu);
            [U,~,~,s,~] = osqpsolver('solve');
        elseif solver == 7
            [U,~,~,output] = quadprog(Hu,fu,AgWu,bgu,[],[],[],[],U0,optimoptions('quadprog','Display','none')); 
            s = output.iterations;
        end

        % * Input
        u  = U(1:Nu) + ur;
        U0 = U;
        if solver == 3; LM0 = LM; end

        case 8 % --------------------------------------------- Explicit MPC

        % * Find piecewise solution
        x = x0; u = u0;
        [du,s,~] = EMPC(PAS,[x-xr;0;0;u-ur]);

        % * Input
        u  = u + du;
        u0 = u;

        case 9 % -------------------------------------------------- C/GMRES

        % * Problem definition (using Fisher-Burmeister function)
        x = x0; u = u0; U = U0; LM = LM0; xt = x-xr;
        fu  = WuPWx*xt;
        bgu = bg - AgWx*xt;
        xd  = Ac*x + Bc*u;
        Fu  = Hu*U + fu + AgWu'*LM;
        g   = AgWu*U - bgu;
        gsq = g.^2; lsq = LM.^2;
        sq  = sqrt( gsq + lsq );
        Fl  = -g + LM - sq;
        c   = 1 +  g./sq;
        d   = 1 - LM./sq;

        % * FDGMRES
        Hess = [Hu, AgWu'; -diag(c)*AgWu, diag(d)];
        left = @(Z) Hess*Z;
        dz = GMRES_F(left,-zeta*[Fu;Fl]-[WuPWx*xd;c.*(AgWx*xd)],[U;LM], gmres_iter);
        ud = dz(1:NU);
        ld = dz(NU+1:end);

        % * Update
        U0  = U  + ud*dt;
        LM0 = LM + ld*dt;
        s   = gmres_iter;

        % * Input
        u  = U0(1:Nu) + ur;
        u0 = u;
    end

    % * System update
    x0  = Ad*x + Bd*u;
    Niter = Niter + s;

    %% ====================== LOGGING ======================================
    if ~t_mode
    LOG.T(:,k)   = dt*(k-1);
    LOG.U(:,k)   = u;
    LOG.X(:,k)   = x;
    LOG.XR(:,k)  = xr;
    LOG.UUB(:,k) = uub;
    else % avoid biased state distribution in time measurement
        if mod(k,500) == 0
            x0 = 2*(rand(size(x))).*xr;
            V0 = inf;
        end
    end
    LOG.Ns(:,k)  = s;

end
% =========================================================== MAIN LOOP END

tEnd = toc(tStart);
LOG.mfilename = mfilename;

fprintf('Calc. time    : %.5f s / %8d steps | %.6f ms/step\n', tEnd, Nt, tEnd/Nt*1000);
fprintf('                          / %8d iters | %.6f ms/iter\n', Niter, tEnd/Niter*1000);
fprintf('Iterations    : ave = %.3f, max = %.0f iter/step\n', mean(LOG.Ns), max(LOG.Ns));
fprintf('Max step time : %.6f ms / step\n', tEnd/Niter*1000 * max(LOG.Ns));

if ~t_mode
    MPC_plot(LOG,'MPCLOG_EXP.mat');
end

end

function h = dynamics(w,x0,Ah,Bh,Nu,Nx,Nh)
% Calculate h = C*w + D*x0 using structure of C.

    Cw = Ctimes(w,Ah,Bh,Nu,Nx,Nh);
    h  = Cw + [Ah*x0; zeros((Nh-1)*Nx,1)];

end

function [wproj,h] = projection(w,x0,Lx,Ah,Bh,CCTi,Nu,Nx,Nh)
% Calculate wproj = K*w + L*x = (I-C'/(C*C')*C)*w + L*x
% using structure of C.

    Cw = Ctimes(w,Ah,Bh,Nu,Nx,Nh);
    wproj = w - CTtimes(CCTi*Cw,Ah,Bh,Nu,Nx,Nh) + Lx;
    h = Cw + [Ah*x0; zeros((Nh-1)*Nx,1)];

end

function x = Ctimes(w,Ah,Bh,Nu,Nx,Nh)
% Caluculate C*w using structure of C.
% Fast in generated code (mex), slow in MATLAC JIT execution.

    NU   = Nh*Nu;
    Uvec = w(1:NU);
    Xvec = w((NU+1):end);
    U    = reshape(Uvec,[Nu,Nh]); % [u_0,...,u_{N-1}]
    Xp   = reshape(Xvec,[Nx,Nh]); % [x_1,...,x_N]
    X    = [zeros(Nx,1),Xp(:,1:(Nh-1))];  % [x_0,...,x_{N-1}]
    H    = Ah*X + Bh*U - Xp;
    x    = reshape(H,Nh*Nx,1);

end

function x = CTtimes(v,Ah,Bh,Nu,Nx,Nh)
% Caluculate C'*v using structure of C.
% Fast in generated code (mex), slow in MATLAC JIT execution.

    V  = reshape(v,[Nx,Nh]);
    Vp = [V(:,2:end),zeros(Nx,1)];
    hu = reshape(Bh'*V,Nh*Nu,1);
    hx = reshape(Ah'*Vp-V,Nh*Nx,1);
    x  = [hu;hx];

end

function Agw = Agtimes(w,useuub,useulb,Nu,Nx,Nh)
% Calculate Ag*w using structure of Ag.
% Fast in generated code (mex), slow in MATLAC JIT execution.

    U = w(1:(Nh*Nu));
    if useuub && useulb
        Agw = [U;-U];
    elseif useuub && ~useulb
        Agw = U;
    elseif ~useuub && useulb
        Agw = -U;
    else
        Agw = [];
    end

end
function AgTmu = AgTtimes(mu,useuub,useulb,Nu,Nx,Nh)
% Calculate Ag'*mu using structure of Ag.
% Fast in generated code (mex), slow in MATLAC JIT execution.

    if useuub && useulb
        AgTmu = [mu(1:Nh*Nu)-mu((Nh*Nu+1):(2*Nh*Nu));zeros(Nh*Nx,1)];
    elseif useuub && ~useulb
        AgTmu = [mu;zeros(Nh*Nx,1)];
    elseif ~useuub && useulb
        AgTmu = [-mu;zeros(Nh*Nx,1)];
    else
        AgTmu = [];
    end

end

function Y = repmat2d(X,SIZE,idxR,idxC)
%    X: matrix to be repeated
% SIZE: block size
% idxR: block row indecies
% idxC: block column indecies

    if numel(idxR) ~= numel(idxC)
        error('Number of row/column indecies does not match.')
    elseif SIZE(1) < max(idxR) || SIZE(2) < max(idxC)
        error('Some index exceeds designated block size.')
    end
    
    n  = numel(idxR);
    Nr = size(X,1);
    Nc = size(X,2);
    Y  = zeros([Nr Nc].*SIZE);
    for i = 1:n
        Ir = Nr*(idxR(i)-1) + (1:Nr);
        Ic = Nc*(idxC(i)-1) + (1:Nc);
        Y(Ir,Ic) = X;
    end
    
end