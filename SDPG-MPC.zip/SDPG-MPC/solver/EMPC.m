function [x,i,flag] = EMPC(pwafun,th)

    found=false;
    i=0;
    imin=0;
    vmin=Inf;
    nr=numel(pwafun);
    flag=0;
    while ~found && i<nr
        i=i+1;
        v=max(pwafun(i).H*th-pwafun(i).K); % max violation of the constraints
        if v<=0
            found=true;
            flag=1;
        else
            if vmin>v
                vmin=v;
                imin=i;
            end
        end
    end
    if ~found
        i=imin;
    end
    x=pwafun(i).F*th+pwafun(i).G;
end