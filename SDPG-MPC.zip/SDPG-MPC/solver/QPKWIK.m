% =========================================================================
% QP solver (QPKWIK)
%  21/08/03 R.Moriyasu @ TCRDL
% -------------------------------------------------------------------------
% Solve QP problem
%    minimize  1/2*u'*H*u + f'*u + const.
%  subject to  A*u <= b
% -------------------------------------------------------------------------
% * Input arguments
%      H: Hessian of objective function (must be positive semi-definite)
%      f: Coefficient vector of 1st-order term 
%      A: Coefficient matrix of inequality constraint
%      b: Vector of inequality constraint
%
% * Output arguments
%      u: Primal solution vector
%      l: Dual solution vector
% =========================================================================
%#codegen

function [u,l,S,conv,k] = QPKWIK(H,f,A,b)
    conv  = 1;
    k     = 1;
    tor   = 1e-6;
    Nu    = numel(f);
    
    A = -A;
    b = -b;
    optut.UT = true;
    optlt.LT = true;
    
    % STEP0: Find unconstrained minimum
    L  = chol(H)';    % H = L*L'
    u  = -linsolve(L',linsolve(L,f,optlt),optut);   % u = -H\f = -L'\L\f

    S  = zeros(Nu+1,1);
    Q  = zeros(Nu);
    Rf = zeros(Nu);
    l0 = zeros(Nu+1,1);
    lp = l0;
    r0 = l0;

    NACT  = 0;
    KDROP = 0;
    SDROP = 0;
    SADD  = 0;
    
    while true
        
    % STEP1: Check for constraint violation
    res = A*u-b;
    SACT = find(S);
    res(S(SACT)) = 0.0;
    [vmax,vmaxid] = min(res);
    l = lp;
    if vmax >= -tor
        return
    else
        KNEXT    = vmaxid;
    end
    
    % STEP2: Solve QP
    while true
        
        k = k+1;
        [~,TC,TU,Q,Rf,R] = update2(Q,Rf,L,A,S,optut,optlt,SDROP,SADD);
        SDROP = 0;
        SADD  = 0;

        % STEP2(a): Determine seach direction
        A_KNEXT = A(KNEXT,:);
        % Primal space
        z = TU*TU'*A_KNEXT';
        % Dual space
        r = r0;
        ridx = 1:NACT;
        if NACT > 0
            r(ridx) = linsolve(R,TC'*A_KNEXT',optut);
        end

        % STEP2(b): Compute step length
        % Compute t1
        if NACT == 0 || all(r<=0)
            t1 = inf;
        else
            idx = find(r > 0);
            [t1,j] = min(l(idx)./r(idx));
            KDROP = S(idx(j));
        end
        % Compute t2
        if norm(z) == 0
            t2 = inf;
        else
            t2 = (b(KNEXT)-A_KNEXT*u)/(z'*A_KNEXT');
        end
        % Step length
        t = min(t1,t2);

        % STEP2(c): Take step
        lpidx = 1:(NACT+1);
        lp(lpidx) = lp(lpidx) + t*[-r(ridx);1];
        if isinf(t)
            error('Error: QP is infeasible.');
        elseif isinf(t2) && ~isinf(t1)
            [NACT,S,SDROP,lp] = drop(lp,S,NACT,KDROP,Nu);
        else
            u  = u  + t*z;
            if t == t2
                NACT = NACT + 1;
                S(NACT) = KNEXT;
                SADD    = KNEXT;
                break;
            else
                [NACT,S,SDROP,lp] = drop(lp,S,NACT,KDROP,Nu);
            end
        end
    
    end
    
    end
end
%%
function [NACT,S,SDROP,lp] = drop(lp0,S0,NACT,KDROP,Nu)
    S = zeros(numel(S0),1);
    lp= zeros(numel(lp0),1);
    NACT  = NACT - 1;
    SACT  = find(S0~=KDROP,Nu);
    SDROPf = find(S0==KDROP,1);
    SDROP = SDROPf(1);
    
    Stmp  = S0(SACT);
    lptmp = lp(SACT);
    S(1:numel(Stmp)) = Stmp;
    lp(1:numel(lptmp)) = lptmp; 
end

function [T,TC,TU,Q,Rf,R] = update2(Q,R0,L,A,S,optut,optlt,SDROP,SADD)
    % Indeces of active constraint
    SACT = find(S);
    % # of active constraint
    NACT = numel(SACT);
    
    Rf = R0*0;

    if SDROP ~= 0 % DROP MODE
        [Q,Rf(:,1:NACT)] = my_qrdelete(Q,R0(:,1:NACT+1),SDROP);
    elseif SADD ~= 0 % ADD MODE
        anext = A(SADD,:);
        xnext = linsolve(L,anext',optlt);
        [Q,Rf(:,1:NACT)] = my_qrinsert(Q,R0(:,1:NACT-1),NACT,xnext);
    else % INITIALIZATION MODE
        Q  = eye(size(L));
        Rf = 0*R0;
    end
    
    R  = Rf(1:NACT,1:NACT);
    T  = linsolve(L',Q,optut);
    TC = T(:,1:NACT);
    TU = T(:,(NACT+1):end);
end

function [Q,R] = my_qrdelete(Q,R,j)
    
    x_rot = zeros(2,1);
    
    % Remove the j-th column.  n = number of columns in modified R.
    R(:,j) = [];
    [m,n] = size(R);
    [mq,nq] = size(Q);

    % R now has nonzeros below the diagonal in columns j through n.
    %    R = [x | x x x         [x x x x
    %         0 | x x x          0 * * x
    %         0 | + x x    G     0 0 * *
    %         0 | 0 + x   --->   0 0 0 *
    %         0 | 0 0 +          0 0 0 0
    %         0 | 0 0 0]         0 0 0 0]
    % Use Givens rotations to zero the +'s, one at a time, from left to right.
    
    for k = j:min(n,m-1)
        p = k:k+1;
        x_rot(:) = R(p,k);
        [G,R(p,k)] = my_planerot(x_rot);
        if k < n
            R(p,k+1:n) = G*R(p,k+1:n);
        end
        Q(:,p) = Q(:,p)*G';
    end
    % If Q is not square, Q is from economy size QR(A,0).
    % Both Q and R need further adjustments.
    if (mq ~= nq) 
        R(m,:)=[];
        Q(:,nq)=[];
    end
    
end

function [Q,R] = my_qrinsert(Q,R00,j,x)
    
    [m,n] = size(R00);
    
    if n==0
       [Q,R] = qr(x);
       return;
    end

    R0 = [R00,zeros(size(x))];
    
    % Make room and insert x before j-th column.
    R0(:,j+1:n+1) = R0(:,j:n);
    R0(:,j) = Q'*x;
    n = n+1;
    
    % Now R has nonzeros below the diagonal in the j-th column,
    % and "extra" zeros on the diagonal in later columns.
    %    R = [x x x x x         [x x x x x
    %         0 x x x x    G     0 x x x x
    %         0 0 + x x   --->   0 0 * * *
    %         0 0 + 0 x          0 0 0 * *
    %         0 0 + 0 0]         0 0 0 0 *]
    % Use Givens rotations to zero the +'s, one at a time, from bottom to top.
    %
    % Q is treated to (the transpose of) the same rotations.
    %    Q = [x x x x x    G'   [x x * * *
    %         x x x x x   --->   x x * * *
    %         x x x x x          x x * * *
    %         x x x x x          x x * * *
    %         x x x x x]         x x * * *]

    for k = m-1:-1:j
        p = k:k+1;
        [G,R0(p,j)] = my_planerot(R0(p,j));
        if k < n
            R0(p,k+1:n) = G*R0(p,k+1:n);
        end
        Q(:,p) = Q(:,p)*G';
    end
    R = R0;
end

function [G,x] = my_planerot(x)

    if x(2) ~= 0
       r = norm(x);
       G = [x'; -x(2) x(1)]/r;
       x = [r; 0];
    else
       G = eye(2,class(x));
    end

end
