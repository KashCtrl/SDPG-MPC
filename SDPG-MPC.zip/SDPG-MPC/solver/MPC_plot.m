function MPC_plot(LOG,baseline)

    MPCLOG = load(baseline);
    MPCLOG = MPCLOG.LOG;
    
    figure('Position', [200 100 800 900])
    PS = [20 20]; 
    set(gcf,'PaperSize',PS,'PaperPosition',[0 0 PS]);
    set(gcf,'defaultAxesColorOrder',[[0 0 1]; [1 0 0]]);
    set(gcf,'defaultAxesLineStyleOrder',{'--', '--'});
    
    Tf = LOG.T(end);
    subplot(3,1,1);
    hold on
    plot(LOG.T,LOG.XR(1,:),'--k','LineWidth',1);
    plot(MPCLOG.T,MPCLOG.X(1,:),':k','LineWidth',2);
    plot(LOG.T,LOG.X(1,:),'-k','LineWidth',2);
    set(gca,'FontName','Times New Roman');
    set(gca,'FontSize',12);
    ylabel('State 1');
    text(LOG.T(1)+0.1,LOG.XR(1,1)+4,'$r_1$','FontSize',14,'Interpreter','latex');
    ylim([0,80]);
    xlim([0,Tf]);
    grid on
    
    subplot(3,1,2);
    hold on
    plot(LOG.T,LOG.XR(2,:),'--k','LineWidth',1);
    plot(MPCLOG.T,MPCLOG.X(2,:),':k','LineWidth',2);
    plot(LOG.T,LOG.X(2,:),'-k','LineWidth',2);
    set(gca,'FontName','Times New Roman');
    set(gca,'FontSize',12);
    ylabel('State 2');
    text(LOG.T(1)+0.1,LOG.XR(2,1)+0.4,'$r_2$','FontSize',14,'Interpreter','latex');
    ylim([0,6]);
    xlim([0,Tf]);
    grid on
    
    subplot(3,1,3);
    hold on
    plot(LOG.T,LOG.UUB,'--k','LineWidth',1.0);
    plot(MPCLOG.T,MPCLOG.U,':k','LineWidth',2);
    plot(LOG.T,LOG.U,'-k','LineWidth',2.0);
    set(gca,'FontName','Times New Roman');
    set(gca,'FontSize',12);
    xlabel('Time [s]');
    ylabel('Input');
    text(LOG.T(end)-0.1,LOG.UUB(1,end)+5,'$\overline{u}$','FontSize',14,'Interpreter','latex');
    ylim([100,180]);
    xlim([0,Tf]);
    grid on
    
    % set(gcf,'Renderer','painters');
    % 
    % assignin('base','LOG',LOG);
    % save('./saved_figs/LOG.mat','LOG');
    % saveas(gcf,'./saved_figs/gcf.fig');
    % saveas(gcf,'./saved_figs/gcf.pdf');
    % saveas(gcf,'./saved_figs/gcf.emf');
    % saveas(gcf,'./saved_figs/gcf.png');
    % copyfile([LOG.mfilename,'.m'],'./saved_figs/selfcopy.m');

end