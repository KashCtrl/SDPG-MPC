% =========================================================================
% QP solver (Regurarized and smoothed Fisher-Burmeister method)
%  21/02/08 R.Moriyasu @ TCRDL
% -------------------------------------------------------------------------
% Solve QP problem
%    minimize  1/2*u'*H*u + f'*u + const.
%  subject to  A*u <= b
% -------------------------------------------------------------------------
% * Input arguments
%      H: Hessian of objective function (must be positive semi-definite)
%      f: Coefficient vector of 1st-order term 
%      A: Coefficient matrix of inequality constraint
%      b: Vector of inequality constraint
%     u0: Initial solution of primal
%     l0: Initial solution of dual
%   dlt0: Initial value of regularization parameter
%    tor: Convergent tolerance of residual norm
%  itmax: Maximum iterations
%
% * Optional inputs
%  varargin{1}: Debug flag (false or true)
%
% * Output arguments
%      u: Primal solution vector
%      l: Dual solution vector
% =========================================================================

function [u,l,Fnorm,conv,j] = FBRS(H,f,A,b,u0,l0,dlt0,tor,itmax)

    % Initialization
    u = u0;
    l = l0;
    dlt = dlt0;
    
    eps   = tor/(2*sqrt(size(l0,1))); % smoothing param. > 0
    sigma = 1e-4; % reduction param. in (0,0.5)
    beta  = 0.70; % backtracking param. in (0,1)
    
    conv  = false;
    optut.UT = true;
    optlt.LT = true;

    for j = 1:itmax
                
        % Residual
        Fu  = H*u + f + A'*l;
        g   = A*u - b;
        gsq = g.^2; lsq = l.^2;
        sq0 = sqrt( gsq + lsq );
        Fl0 = -g + l - sq0;
        Fnorm0 = norm([Fu;Fl0]);
        
        % Termination
        if Fnorm0 <= tor && j > 1
            conv = true;
            Fnorm = Fnorm0;
            break;
        else
            sq = sqrt( gsq + lsq + eps^2 );
            Fl = -g + l - sq;
            Fnorm = norm([Fu;Fl]);
            dlt = min(dlt,Fnorm); % Update regularization param.
        end
        
        % Solve sub-problem
        % note: sub differential should be introduced if sq==0
        c = 1 + g./sq + dlt;
        d = 1 - l./sq + dlt;
        Au = H + A'*diag(c./d)*A;
        bu = - Fu + A'*(Fl./d);

        sq_Au = chol(Au)';
        ud = linsolve(sq_Au',linsolve(sq_Au,bu,optlt),optut);
        ld = ( -Fl + c.*(A*ud) )./d;

        t = 1;

        % Line search (Armijo condition)
        while theta(u+ud*t,l+ld*t,H,f,A,b,eps) >= (1-2*t*sigma)*Fnorm^2
            t = beta*t;
        end

        % Update
        u = u + ud*t;
        l = l + ld*t;
        t = min(1.0,t/beta);
    end
    j = j-1;
    
end

function [Fu,Fl,g,sq] = res(u,l,H,f,A,b,eps)
    g = A*u - b;
    sq = sqrt( g.^2 + l.^2 + eps^2 );
    Fu = H*u + f + A'*l;
    Fl = -g + l - sq;
end

function v = theta(u,l,H,f,A,b,eps)
    [Fu,Fl] = res(u,l,H,f,A,b,eps);
    v = norm([Fu;Fl])^2;
end