function [x, err] = GMRES_F(Ax_F, b, x_0, k_max)
 
Q_k = eye(k_max+1);
c_k = NaN;
s_k = NaN;

r_hat  = b - Ax_F(x_0);
rho    = sqrt(r_hat.'*r_hat);

N = numel(r_hat);
if k_max>N
    k_max = N;
end

Vk      = NaN(N,k_max+1);
Vk(:,1) = r_hat./rho;
Hk      = zeros(k_max+1,k_max);
g       = [rho; zeros(k_max,1)];

err    = NaN(k_max+1,1);
err(1) = rho;

for k = 1:k_max

    % ------------------------------
    % Gram-Schmidt orthonormalization
    Vk(:,k+1) = Ax_F(Vk(:,k));
    for j = 1:k
        Hk(j,k) = Vk(:,k+1).'*Vk(:,j);
        Vk(:,k+1) = Vk(:,k+1) - Hk(j,k)*Vk(:,j);
    end
    Hk(k+1,k) = sqrt(Vk(:,k+1).'*Vk(:,k+1));
    if (Hk(k+1,k)==0)&&(k<k_max)
        error('GMRES error 1')
    else
        Vk(:,k+1) = Vk(:,k+1)./Hk(k+1,k);
    end
    
    % ------------------------------
    % Givens Rotation
    if k==1
        Q_k = eye(k_max+1);
    else
        Q_k = GivensRot_F(c_k, s_k, k-1, k_max+1)*Q_k;
    end
    Hk(:,k) = Q_k*Hk(:,k);
    nu  = sqrt(Hk(k,k).^2 + Hk(k+1,k).^2);
    if nu~=0
        c_k =  Hk(k,  k)./nu;
        s_k = -Hk(k+1,k)./nu;
    else
        error('GMRES error 2')
    end
    Hk(k,k)   = c_k.*Hk(k,k) - s_k.*Hk(k+1,k);
    Hk(k+1,k) = 0;
    g = GivensRot_F(c_k, s_k, k, k_max+1) * g;
    
    rho = abs(g(k+1));
    err(k+1) = rho;
end

% ------------------------------
% Solve the problem with upper-trianglar coef. matrix
yk = NaN(k_max,1);
for ii = k_max:-1:1
    if ii == k_max
        yk(ii) = g(ii)./Hk(ii,ii);
    else
        yk(ii) = (g(ii) - Hk(ii,ii+1:k_max)*yk(ii+1:k_max))./Hk(ii,ii);
    end
end

% ------------------------------
% Answer
x = x_0 + Vk(:,1:k_max)*yk;

end

function G = GivensRot_F(c,s,j,N)

G = eye(N);
G(j,  j  ) =  c;
G(j,  j+1) = -s;
G(j+1,j  ) =  s;
G(j+1,j+1) =  c;

end