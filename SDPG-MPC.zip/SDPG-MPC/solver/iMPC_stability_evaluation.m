% * Conversion matrix
W    = [zeros(Nx,Nw),Ix; E*K, E*L]; % [x;u] = W [w;x]
Wbar = [W,zeros(Nx+Nu,Nlm)];        % [x;u] = Wbar [w;x;lm]

% ===================== Continuous-time =================================== 
% * Plant dissipativity (x,u)
Qc  = Ac; Sc = 1/2*Bc; Rc = zeros(Nu);
HPc = [Qc, Sc; Sc', Rc];
HPc = (HPc+HPc')/2;

% * Controller dissipativity (w,x,u)
sigma = P;
HCc = [-sigma*Iw-beta*(C'*C), -beta*C'*D;...
       -beta*D'*C, tau/(4*alpha)*(D'*D)];

% * Lyapunov function candidate
dlt = sdpvar(1); lmd_max = sdpvar(1);
Hc  = HCc + dlt*W'*HPc*W;

% * Minimization of maximum eigenvalue
solvesdp([lmd_max*eye(Nw+Nx) >= Hc, dlt >= 0], lmd_max, sdpsettings('verbose',0));
disp('Minimum lambda & delta (Continuous-time):')
lmd_max_c = double(lmd_max) % Continuous-time closed-loop is stable if negative
dlt_c     = double(dlt)

% ===================== Discrete-time =====================================
% * Plant dissipativity (x,u)
Qd = Ad-Ix; Sd = 1/2*Bd; Rd = zeros(Nu); 
HPd  = [Qd, Sd; Sd', Rd]/dt;
HPd  = (HPd+HPd')/2;
tmp  = [Ad-Ix,Bd]/dt;
PPd  = 1/2*(tmp'*tmp);

% * Controller dissipativity (w,x,u)
HCc_bar = [ -sigma*Iw-tau*kappa*beta*(C'*C), -tau*kappa*beta/2*C'*D, -tau*alpha*beta*C';...
            -tau*kappa*beta/2*D'*C,          zeros(Nx),              tau/2*D';...
            -tau*alpha*beta*C,               tau/2*D,                -tau*alpha*eye(Nlm)];
X       = tau*kappa*C'*[beta*C, beta*D, Ilm];
Y       = X + [P, zeros(Nw,Nx), zeros(Nw,Nlm)];
Z       = tau*[C, D, -alpha*Ilm];
Pbar    = Y'*Y;
PCd_bar = 1/2 * ( Pbar + Z'*Z );

% * Lyapunov function candidate
Hd_bar   = HCc_bar + dlt*Wbar'*HPd*Wbar + dt*(zeta*PCd_bar + dlt*Wbar'*PPd*Wbar);

% * Minimization of maximum eigenvalue
solvesdp([lmd_max*eye(Nw+Nx+Nlm) >= Hd_bar, dlt >= 0],lmd_max, sdpsettings('verbose',0));
disp('Minimum lambda & delta (Discrete-time):')
lmd_max_d = double(lmd_max) % Discrete-time closed-loop is stable if negative
dlt_d     = double(dlt)
